(function ($) {
    dream.init(function () {

        console.log('Welcome to the Dream child theme.');
        console.log('Copy and rename this file to add custom JS.');
        console.log('You can safely remove this JS part if desired.');

    });
})(jQuery);
